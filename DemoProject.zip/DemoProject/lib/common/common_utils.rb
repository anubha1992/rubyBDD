module Common
  class CommonUtils

    # click an element
    def click_ele(locator, by)
      ele = @browser.find_element(by.to_sym, locator)
      ele.click
    end

    # send keys on an element
    def send_keys(locator, by, text)
      ele = @browser.find_element(by.to_sym, locator)
      ele.send_keys(text)
    end

    #select text from dropdown
    def select_from_dropdown_by_text(locator, by, visible_text)
      ele = @browser.find_element(by.to_sym, locator)
      select = Selenium::WebDriver::Support::Select.new(ele)
      select.select_by(:text, visible_text)
    end

    #select by value from dropdown
    def select_from_dropdown_by_index(locator, by, value)
      ele = @browser.find_element(by.to_sym, locator)
      select = Selenium::WebDriver::Support::Select.new(ele)
      select.select_by(:value, value)
    end

    #select by index from dropdown
    def select_from_dropdown_by_index(locator, by, index)
      ele = @browser.find_element(by.to_sym, locator)
      select = Selenium::WebDriver::Support::Select.new(ele)
      select.select_by(:index, index)
    end

  end
end