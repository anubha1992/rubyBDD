module Pom
  class PracticeForm
    include PageObject

    text_field(:fname,id:'firstName')
    radio_group(:gender,name:'gender')
    checkbox(:subjscts,xpath:"//div[]")




  end
end