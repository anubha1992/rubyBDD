require 'cucumber/formatter/html'


class ReportGenerator < Cucumber::Formatter::Html



end