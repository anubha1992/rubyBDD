require 'rubygems'
require 'cucumber'
require "Selenium-webdriver"

#
# #Creating Remote WebDriver
# # browser = Watir::Browser.new(:remote, :url =&gt; "http://SauceUsername:SauceKey@ondemand.saucelabs.com:80/wd/hub", :desired_capabilities =&gt; WebDriver::Remote::Capabilities.firefox)
# # #If you want to run it locally, use Watir::Browser.new :firefox
#
# browser = Watir::Browser.new :firefox
Selenium::WebDriver::Chrome::Service.driver_path = "drivers/chromedriver.exe"
options = Selenium::WebDriver::Chrome::Options.new
options.add_argument('--ignore-certificate-errors')
options.add_argument('--disable-popup-blocking')
options.add_option('useAutomationExtension',false)
options.add_argument('--disable-infobars');

browser= Selenium::WebDriver.for :chrome, options: options
browser.manage.window.maximize
sleep 10

Before do |scenario|
  puts "Getting driver instance"
  @browser = browser
end

After do |scenario|
  if scenario.failed?
    puts "Test failed"
    puts "Exception: #{scenario.exception.to_s}"
  else
    puts "Test passed"
  end
  puts "Quitting driver"
  @browser.quit
end

