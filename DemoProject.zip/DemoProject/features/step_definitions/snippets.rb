


Given /I login to application/ do
  begin
    @browser.get "https://demoqa.com/automation-practice-form/"
    sleep 2
  rescue Exception => e
    puts "err: #{e.to_s}"
  end
end

And /I enter name details/ do
    sleep 1
    @browser.find_element(:id, 'firstName').send_keys "Anubha"
    @browser.find_element(:id, 'lastName').send_keys "Sinha"
    sleep 1
end

And /I enter email details/ do
  sleep 1
  @browser.find_element(:id, 'userEmail').send_keys "anubha1900@gmail.com"
  sleep 1
end

And /I enter gender data/ do
  sleep 1
  @browser.find_element(:id, 'gender-radio-2').click
  sleep 1
end

And /I enter mobile number/ do
  sleep 1
  @browser.find_element(:id, 'userNumber').send_keys "12345678"
  sleep 1
end

And /I enter date of birth/ do
  sleep 1
  @browser.find_element(:id, 'dateOfBirthInput').clear
  @browser.find_element(:id, 'dateOfBirthInput').send_keys "25 Nov 2020"
  sleep 1
end

And /I enter subject/ do
  sleep 1
  @browser.find_element(:id, 'subjectsInput').send_keys "Maths"
  sleep 1
end


And /I enter dob details/ do
  sleep 3
  obj = Common::CommonUtils.new()
  obj.send_keys('dob','id',"03071992" )
  # @browser.find_element(:id, 'firstName').send_keys "Anubha"
  sleep 2
end


And /I enter "([^"]*)" in "([^"]*)" by "([^"]*)"/ do |text, locator, by|
  sleep 1
  @browser.find_element(by.to_sym, locator).send_keys text
  sleep 1
end
